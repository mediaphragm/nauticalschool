<?php

namespace {{ namespace }};

use Symfony\Component\HttpKernel\Bundle\Bundle;

class {{ bundle }} extends Bundle
{
}
